package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.NoSuchElementException;

public class CorpvueIntegration {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win64 (3)\\chromedriver-win64\\chromedriver.exe");

        WebDriver driver = null;
        try {
            driver = new ChromeDriver();
            driver.get("https://www.corpvue.com/search");
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

            String filePath = "D:\\excel/Corpvue_Sheet1.xlsx";

            FileInputStream fileInputStream = new FileInputStream(filePath);

            Workbook workbook = new XSSFWorkbook(fileInputStream);
            String sheetName = "Corpvue_Sheet1";
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheet(sheetName);

            boolean firstRowSkipped = false;
            boolean dataFound = false;

            for (Row row : sheet) {
                if (!firstRowSkipped) {
                    firstRowSkipped = true;
                    continue; // Skip the first row header
                }

                if (isRowEmpty(row)) {
                    break; //  if the row is empty
                }

                Cell cellCompanyName = row.getCell(0);
                Cell cellCIN = row.getCell(1);
                Cell cellStrikeOff = row.getCell(2);
                Cell cellROC = row.getCell(3);
                Cell cellPrev = row.getCell(4);

                if (cellCompanyName != null && cellCIN != null && cellStrikeOff != null && cellROC != null && cellPrev != null) {
                    String searchCompanyName = cellCompanyName.getStringCellValue();
                    String searchCIN = cellCIN.getStringCellValue();
                    String searchStrikeOff = cellStrikeOff.getStringCellValue();
                    String searchROC = cellROC.getStringCellValue();
                    String searchPrev = cellPrev.getStringCellValue();

                    WebElement searchBar = driver.findElement(By.xpath("//input[@type='text']"));

                    Actions actions = new Actions(driver);
                    actions.moveToElement(searchBar).click().keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.DELETE).perform();

                    searchBar.sendKeys(searchCompanyName);

                    Thread.sleep(4000);

                    WebElement cinElement = null;
                    WebElement strikeOffElement = null;
                    WebElement rocElement = null;
                    WebElement prevElement = null;
                    try {
                        cinElement = driver.findElement(By.xpath("(//span[@class='MuiTypography-root MuiTypography-p css-wcc8sg-MuiTypography-root'])[1]"));
                        strikeOffElement = driver.findElement(By.xpath("//div[@class=' flex flex-col justify-between items-end gap-1']/p"));
                        rocElement = driver.findElement(By.xpath("(//span[@class='MuiTypography-root MuiTypography-p css-wcc8sg-MuiTypography-root'])[2]"));

                        try {
                            prevElement = driver.findElement(By.xpath("//p[@class='previously-known-text']"));
                        } catch (NoSuchElementException e) {
                            prevElement = null;
                        }

                        String cinValue = cinElement.getText();
                        String strikeOffValue = strikeOffElement.getText();
                        String rocValue = rocElement.getText();
                        String prevValue = (prevElement != null) ? prevElement.getText() : "";

                        System.out.println("CIN value: Excel - " + searchCIN + ", App - " + cinValue);
                        System.out.println("Strike Off value: Excel - " + searchStrikeOff + ", App - " + strikeOffValue);
                        System.out.println("ROC value: Excel - " + searchROC + ", App - " + rocValue);
                        if (prevElement != null) {
                            System.out.println("Previous Company value: Excel - " + searchPrev + ", App - " + prevValue);
                        }

                        dataFound = true;
                    } catch (Exception e) {
                        System.out.println("No result found");
                    }
                } else {
                    System.out.println("Values do not match");
                }
            }

            workbook.close();

            if (!dataFound) {
                System.out.println("No more data to search. Exiting...");
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }

    private static boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && !cell.toString().trim().isEmpty())
                return false;
        }
        return true;
    }
}
