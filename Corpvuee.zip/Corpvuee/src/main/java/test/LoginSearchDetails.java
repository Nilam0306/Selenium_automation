




package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class LoginSearchDetails {

    private static String getStringCellValue(Cell cell) {
        if (cell != null) {
            switch (cell.getCellType()) {
                case STRING:
                    return cell.getStringCellValue();
                case NUMERIC:
                    // Convert numeric value to string
                    return String.valueOf(cell.getNumericCellValue());
                // Handle other cell type
                default:   
                    throw new IllegalArgumentException("Unsupported cell type: " + cell.getCellType());
            }
        }
        return ""; // Return empty string if cell is null
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver-win64 (3)\\chromedriver-win64\\chromedriver.exe");

        WebDriver driver = null;
        try {
            driver = new ChromeDriver();
            driver.get("https://www.corpvue.com/U27104TN1991PLC020710/company-details");
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            
            driver.findElement(By.xpath("//div[@class='MuiBox-root css-2uchni']")).click();
            driver.findElement(By.id("username")).sendKeys("nilam.mehetre@finconic.com");
            driver.findElement(By.id("password")).sendKeys("N");
            driver.findElement(By.xpath("//input[@class='submit']")).click();
            
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            
            String filePath = "D:\\excel/CorpvueDetailSearchAfterLogin.xlsx";

            FileInputStream fileInputStream = new FileInputStream(filePath);

            Workbook workbook = new XSSFWorkbook(fileInputStream);
            String sheetName = "CorpvueDetailSearchAfterLogin";
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheet(sheetName);

            boolean firstRowSkipped = false;
            boolean dataFound = false;

            for (Row row : sheet) {
                if (!firstRowSkipped) {
                    firstRowSkipped = true;
                    continue; // Skip the first row header
                }

                if (isRowEmpty(row)) {
                    break; //  if row is empty
                }
                
                
                Cell cellCompanyName= row.getCell(0);
                Cell cellCIN= row.getCell(1);
                Cell cellAuthoCap= row.getCell(2);
                Cell cellPaidUpCap= row.getCell(3);
                Cell cellOpenCharges= row.getCell(4);
                Cell cellCloseCharges= row.getCell(5);
                Cell cellStatus= row.getCell(6);
                Cell cellActiveComp= row.getCell(7);
                Cell cellCIRP= row.getCell(8);
                Cell cellRegAdd= row.getCell(9);
                Cell cellBusAdd= row.getCell(10);
                Cell cellMail= row.getCell(11);
                Cell cellCompAge= row.getCell(12);
                Cell cellROCCOde= row.getCell(13);
                Cell cellTypeentity= row.getCell(14);
                Cell cellTypeentity1= row.getCell(15);
                Cell cellListStatus= row.getCell(16);
                Cell cellIncorp= row.getCell(17);
                Cell cellAGM= row.getCell(18);
                Cell cellBalanceSheet= row.getCell(19);
                Cell cellLastROC= row.getCell(20);
              
                
                if (cellCompanyName != null && cellCIN != null && cellAuthoCap != null && cellPaidUpCap != null && cellOpenCharges != null && cellCloseCharges != null 
                		&& cellStatus != null && cellActiveComp != null && cellCIRP != null && cellRegAdd != null 
                		&& cellBusAdd != null  && cellMail != null && cellCompAge != null && cellROCCOde != null && cellTypeentity != null 
                		&& cellTypeentity1 != null && cellListStatus != null && cellIncorp != null && cellAGM != null 
                		&& cellBalanceSheet != null && cellLastROC != null )
                {
                	String searchCompanyName = getStringCellValue(cellCompanyName);
                	String searchCIN = getStringCellValue(cellCIN);
                	String searchAuthoCap = getStringCellValue(cellAuthoCap);
                	String searchPaidUpCap = getStringCellValue(cellPaidUpCap);
                	String searchOpenCharges = getStringCellValue(cellOpenCharges);
                	String searchCloseCharges=getStringCellValue(cellCloseCharges);
                	String searchStatus = getStringCellValue(cellStatus);
                	String searchActiveComp = getStringCellValue(cellActiveComp);
                	String searchCIRP = getStringCellValue(cellCIRP);
                	String searchRegAdd = getStringCellValue(cellRegAdd);
                	String searchBusAdd = getStringCellValue(cellBusAdd);
                	String searchMail= getStringCellValue(cellMail);
                	String searchCompAge = getStringCellValue(cellCompAge);
                	String searchROCCOde = getStringCellValue(cellROCCOde);
                	String searchTypeentity = getStringCellValue(cellTypeentity);
                	String searchTypeentity1 = getStringCellValue(cellTypeentity1);
                	String searchListStatus = getStringCellValue(cellListStatus);
                	String searchIncorp = getStringCellValue(cellIncorp);
                	String searchAGM = getStringCellValue(cellAGM);
                	String searchBalanceSheet = getStringCellValue(cellBalanceSheet);
                	String searchLastROC = getStringCellValue(cellLastROC);
    

                    WebElement searchBar = driver.findElement(By.xpath("//input[@class=' transition-all']"));

                    Actions actions = new Actions(driver);
                    actions.moveToElement(searchBar).click().keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.DELETE).perform();
                    searchBar.sendKeys(searchCompanyName);
                    
                    Thread.sleep(8000);
                    driver.findElement(By.xpath("//div[@class=' flex flex-col justify-between items-start gap-2']")).click();
                    
                 

                    Thread.sleep(10000);

                    WebElement cinElement = driver.findElement(By.xpath("//p[@class='company-cin-para']"));
                    WebElement authoCapElement = driver.findElement(By.xpath("(//div[@class='company-capital-and-charges-value'])[1]"));
                    WebElement paidUpCapElement = driver.findElement(By.xpath("(//div[@class='company-capital-and-charges-value'])[2]"));
                    WebElement openChargesElement = driver.findElement(By.xpath("(//div[@class='company-capital-and-charges-value'])[3]"));
                    WebElement closeChargesElement = driver.findElement(By.xpath("(//div[@class='company-capital-and-charges-value'])[4]"));
                    WebElement statusElement = driver.findElement(By.xpath("//div[@class='company-profile-status-value']"));
                    WebElement ActiveCompElement = driver.findElement(By.xpath("//div[@class='company-profile-active-compliance-value']"));
                    WebElement CIRPElement = driver.findElement(By.xpath("//div[@class='company-profile-cipr-status-value']"));
                    WebElement regAddElement = driver.findElement(By.xpath("//p[@class='company-registered-address-para']"));
                    WebElement busAddElement = driver.findElement(By.xpath("//p[@class='company-business-address-para']"));
                    WebElement mailElement= driver.findElement(By.xpath("//p[@class='company-contact-email-para']"));
                    WebElement compAgeElement = driver.findElement(By.xpath("(//p[@class='company-stats-age-value'])[1]"));
                    WebElement rocCodeElement = driver.findElement(By.xpath("(//p[@class='company-stats-age-value'])[2]"));
                    WebElement typeEntityElement = driver.findElement(By.xpath("(//p[@class='company-stats-age-value'])[3]"));
                    WebElement typeEntity1Element = driver.findElement(By.xpath("(//p[@class='company-stats-age-value'])[4]"));
                    WebElement listStatusElement = driver.findElement(By.xpath("(//p[@class='company-stats-age-value'])[5]"));
                    WebElement incorpElement = driver.findElement(By.xpath("(//p[@class='company-important-dates-para'])[1]"));
                    WebElement AGMElement = driver.findElement(By.xpath("(//p[@class='company-important-dates-para'])[2]"));
                    WebElement balanceSheetElement = driver.findElement(By.xpath("(//p[@class='company-important-dates-para'])[3]"));
                    WebElement lastROCElement = driver.findElement(By.xpath("(//p[@class='company-important-dates-para'])[4]"));
                    
                    
Thread.sleep(100000);
                  
                    String cinValue = cinElement.getText();
                    String authoCapValue = authoCapElement.getText();
                    String paidUpCapValue = paidUpCapElement.getText();
                    String openChargesValue = openChargesElement.getText();
                    String closeChargesValue = closeChargesElement.getText();
                    String statusValue = statusElement.getText();
                    String ActiveCompValue = ActiveCompElement.getText();
                    String CIRPValue = CIRPElement.getText();
                    String regAddValue = regAddElement.getText();
                    String busAddValue = busAddElement.getText();
                    String mailValue = mailElement.getText();
                    String compAgeValue = compAgeElement.getText();
                    String rocCodeValue = rocCodeElement.getText();
                    String typeEntityValue = typeEntityElement.getText();
                    String typeEntity1Value = typeEntity1Element.getText();
                    String listStatusValue = listStatusElement.getText();
                    String inCorpValue = incorpElement.getText();
                    String AGMValue = AGMElement.getText();
                    String balanceSheetValue = balanceSheetElement.getText();
                    String lastROCValue = lastROCElement.getText();

                    
                 
                    try {
                    	 if (cinValue.equalsIgnoreCase(searchCIN)) {
                             System.out.println("CIN values match for: " + searchCompanyName + " " + cinValue);
                         } else {
                             //System.out.println("CIN values do not match: Excel: " + searchCIN + ", App: " + cinValue);
                        	 System.out.println("CIN values do not match for " + searchCompanyName + ": Excel: " + searchCIN + ", App: " + cinValue);
                         }

                    	 if (authoCapValue.equalsIgnoreCase(searchAuthoCap)) {
                             System.out.println("authorized capital values match for: " +searchCompanyName+ " " + authoCapValue);
                         } else {
                             System.out.println("authorized capital values do not match for " + searchCompanyName + ": Excel: " + searchAuthoCap + ", App: " + authoCapValue);
                         }
                    	 if (paidUpCapValue.equalsIgnoreCase(searchPaidUpCap)) {
                             System.out.println("paidUp Capital value match for: " +searchCompanyName+ " " + paidUpCapValue);
                         } else {
                             System.out.println("paidUp capital Value do not match for  " + searchCompanyName + ": Excel: " + searchPaidUpCap + ", App: " + paidUpCapValue);
                         }
                    	 if (openChargesValue.equalsIgnoreCase(searchOpenCharges)) {
                             System.out.println("open Charges Value  match for: " +searchCompanyName+ " " + openChargesValue);
                         } else {
                             System.out.println("open Charges Value  do not match for " + searchCompanyName + ": Excel: " + searchOpenCharges + ", App: " + openChargesValue);
                         }
                    	 if (closeChargesValue.equalsIgnoreCase(searchCloseCharges)) {
                    		 System.out.println("close charges Value  match for: " +searchCompanyName+" " + closeChargesValue);
                         } else {
                             System.out.println("close charges Value  do not match for " + searchCompanyName + ": Excel: " + searchCloseCharges + ", App: " + closeChargesValue);
                         }
                    	 if (statusValue.equalsIgnoreCase(searchStatus)) {
                             System.out.println("status Value  match for: " +searchCompanyName +" " + statusValue);
                         } else {
                             System.out.println("status Value do not match for " +searchCompanyName+ ": Excel: " + searchStatus + ", App: " + statusValue);
                         }
                    	 if (ActiveCompValue.equalsIgnoreCase(searchActiveComp)) {
                             System.out.println("Active Compliance values match for: "+searchCompanyName + " " + ActiveCompValue);
                         } else {
                             System.out.println("Active Compliance values do not match for " +searchCompanyName +": Excel: " + searchActiveComp + ", App: " + ActiveCompValue);
                         }
                    	 if (CIRPValue.equalsIgnoreCase(searchCIRP)) {
                             System.out.println("CIRP Value match for: " +searchCompanyName +"  "+ CIRPValue);
                         } else {
                             System.out.println("CIRP Value do not match for" +searchCompanyName +" : Excel: " + searchCIRP + ", App: " + CIRPValue);
                         }
                    	 if (regAddValue.equalsIgnoreCase(searchRegAdd)) {
                             System.out.println("registered address Value match for: " +searchCompanyName +" "+ regAddValue);
                         } else {
                             System.out.println("registered address Value do not match for " +searchCompanyName +": Excel: " + searchRegAdd + ", App: " + regAddValue);
                         }
                    	 if (busAddValue.equalsIgnoreCase(searchBusAdd)) {
                             System.out.println("business address Value match for: " +searchCompanyName+" " + busAddValue);
                         } else {
                             System.out.println("business address Value do not match for" +searchCompanyName +" Excel: " + searchBusAdd + ", App: " + busAddValue);
                         }
                    	 if (mailValue.equalsIgnoreCase(searchMail)) {
                             System.out.println("Email address Value match for: " +searchCompanyName+" " + mailValue);
                         } else {
                             System.out.println("business address Value do not match for" +searchCompanyName +" Excel: " + searchMail + ", App: " + mailValue);
                         }
                    	 if (compAgeValue.equalsIgnoreCase(searchCompAge)) {
                             System.out.println("company age values match for: " +searchCompanyName +" " + compAgeValue);
                         } else {
                             System.out.println("company Age values do not match for" +searchCompanyName +" Excel: " + searchCompAge + ", App: " + compAgeValue);
                         }
                    	 if (rocCodeValue.equalsIgnoreCase(searchROCCOde)) {
                             System.out.println("rocCode value match for: " +searchCompanyName + " " +rocCodeValue);
                         } else {
                             System.out.println("rocCode value do not match for" +searchCompanyName+ " Excel: " + searchROCCOde + ", App: " + rocCodeValue);
                         }
                    	 if (typeEntityValue.equalsIgnoreCase(searchTypeentity)) {
                             System.out.println("typeEntity Value value match for: " +searchCompanyName +" "+ compAgeValue);
                         } else {
                             System.out.println("typeEntity Value value do not match for:" +searchCompanyName+ " Excel: " + searchTypeentity + ", App: " + typeEntityValue);
                         }
                    	 if (typeEntity1Value.equalsIgnoreCase(searchTypeentity1)) {
                             System.out.println("typeEntity1 Value match for: " +searchCompanyName+" "+ compAgeValue);
                         } else {
                             System.out.println("typeEntity1 Value do not match for :" +searchCompanyName +" Excel: " + searchTypeentity1 + ", App: " + typeEntity1Value);
                         }
                    	 if (listStatusValue.equalsIgnoreCase(searchListStatus)) {
                             System.out.println("listing Status Value match for: " +searchCompanyName+" " + listStatusValue);
                         } else {
                             System.out.println("listing Status Value do not match for : Excel:"+searchCompanyName+ " " + searchListStatus + ", App: " + listStatusValue);
                         }
                    	 if (inCorpValue.equalsIgnoreCase(searchIncorp)) {
                             System.out.println("Date of InCorporation Value match for: "+searchCompanyName+" " + inCorpValue);
                         } else {
                             System.out.println("Date of InCorporation do not match for :"+searchCompanyName +" Excel: " + searchIncorp + ", App: " + inCorpValue);
                         }
                    	 if (AGMValue.equalsIgnoreCase(searchAGM)) {
                             System.out.println("Date of AGM Value values match for: " +searchCompanyName+" " + AGMValue);
                         } else {
                             System.out.println("Date of AGM Value do not match for :" +searchCompanyName +" Excel: " + searchAGM + ", App: " + AGMValue);
                         }
                    	 if (balanceSheetValue.equalsIgnoreCase(searchBalanceSheet)) {
                             System.out.println("balance Sheet Value match for: "+searchCompanyName+" " + balanceSheetValue);
                         } else {
                             System.out.println("balance Sheet Value do not match for : Excel: " + searchBalanceSheet + ", App: " + balanceSheetValue);
                         }
                    	 if (lastROCValue.equalsIgnoreCase(searchLastROC)) {
                             System.out.println("Last ROC Value match for: " +searchCompanyName+" " + lastROCValue);
                         } else{
                             System.out.println("Last ROC Value do not match for : Excel:"+searchCompanyName +" " + searchLastROC + ", App: " + lastROCValue);
                         }
                                /*authoCapValue.equalsIgnoreCase(searchAuthoCap) &&
                                paidUpCapValue.equalsIgnoreCase(searchPaidUpCap) &&
                                openChargesValue.equalsIgnoreCase(searchOpenCharges) &&
                                closeChargesValue.equalsIgnoreCase(searchCloseCharges) &&
                                statusValue.equalsIgnoreCase(searchStatus) &&
                                ActiveCompValue.equalsIgnoreCase(searchActiveComp) &&
                                CIRPValue.equalsIgnoreCase(searchCIRP) &&
                                regAddValue.equalsIgnoreCase(searchRegAdd) &&
                                busAddValue.equalsIgnoreCase(searchBusAdd) &&
                                compAgeValue.equalsIgnoreCase(searchCompAge) &&
                                rocCodeValue.equalsIgnoreCase(searchROCCOde) &&
                                typeEntityValue.equalsIgnoreCase(searchTypeentity) &&
                                typeEntity1Value.equalsIgnoreCase(searchTypeentity1) &&
                                listStatusValue.equalsIgnoreCase(searchListStatus) &&
                                inCorpValue.equalsIgnoreCase(searchIncorp) &&
                                AGMValue.equalsIgnoreCase(searchAGM) &&
                                balanceSheetValue.equalsIgnoreCase(searchBalanceSheet) &&
                                lastROCValue.equalsIgnoreCase(searchLastROC)) {
*/
								/*
								 * System.out.println("Values for company " + searchCompanyName +
								 * " are matched."); } else { System.out.println("Values for company " +
								 * searchCompanyName + " do not match."); }
								 */
                    
                    	/* else {
                             System.out.println("Values do not match");
                         }*/

                        dataFound = true; // Data found
                    } catch (Exception e) {
                        System.out.println("Error while validating results for company " + searchCompanyName + ": " + e.getMessage());
                    }
                } else {
                    System.out.println("Company name is empty in Excel.");
                }
            }

            workbook.close();

            if (!dataFound) {
                System.out.println("No more data to search. Exiting...");
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }

    // if row empty
    private static boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && !cell.toString().trim().isEmpty())
                return false;
        }
        return true;
    }
}
