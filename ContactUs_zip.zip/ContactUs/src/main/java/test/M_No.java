package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.WebElement;

public class M_No {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://112.133.194.254/lom.asp");
		driver.manage().window().maximize();
		//driver.manage().timeouts().getImplicitWaitTimeout();
		//String memberId = "010001";
		//Thread.sleep(5000);
		//getMemberIdInfo(driver, memberId);
		//String memberId1 = "903837";
		//Thread.sleep(5000);
		//getMemberIdInfo(driver, memberId1);
		// Close the WebDriver
		
		 int startMemberId = 100000;  // Start membership number
	     int endMemberId = 100050;    // End membership number

	        for (int memberId = startMemberId; memberId <= endMemberId; memberId++) {
	            String memberIdStr = String.format("%06d", memberId); // Format as 6-digit string
	            Thread.sleep(7000);
	            getMemberIdInfo(driver, memberIdStr);
	            driver.findElement(By.xpath("//input[@name=\"t1\"]")).clear();
	            Thread.sleep(7000);
	        }
		
		driver.quit();
	}

	private static void getMemberIdInfo(WebDriver driver, String memberId) throws InterruptedException {
		driver.findElement(By.xpath("//input[@name=\"t1\"]")).sendKeys(memberId);
		driver.findElement(By.xpath("//input[@value=\"Submit\"]")).click();
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10000));
		
		try {
			
		WebElement memberDetails=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='t1']")));
		Thread.sleep(1000);
		
	    //String name = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[2]")).getText();
		String name = memberDetails.findElement(By.xpath("(((//form[@name='frm']//table)[2]/tbody/tr)[2]/td)[2]/b")).getText();
		//(((//form[@name='frm']//table)[2]/tbody/tr)[2]/td)[2]/b		
		//String gender = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[3]")).getText();
		String gender = memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[3]//td/b")).getText();
		
		//String qualification = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[4]")).getText();
		String qualification = memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[4]/td/b")).getText();		
		String address =memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[5]/td/b")).getText();
		String address1=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[6]/td/b")).getText();
		String address2=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[9]/td/b")).getText();
		String address3=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[10]/td/b")).getText();
		String address4=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[5]/td)[4]/b")).getText();
		String address5=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[9]/td)[4]/b")).getText();
		String address6=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[10]/td)[4]/b")).getText();
		String address7=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[11]/td)[4]/b")).getText();
		
		//String address = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[5]")).getText();
		
		//String cop_status = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[12]")).getText();
		String cop_status = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[12]/td)/b")).getText();
		
		//String year = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[13]")).getText();
		String year = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[13]/td)/b")).getText();
		
		//String F_year = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[14]")).getText();
		String F_year = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[14]/td)/b")).getText();
		
		String region=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[14]/td)[4]/b")).getText();		
		
		System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Qualification: " + qualification);
        System.out.println("Address: " + address);
        System.out.println("Address: " + address1);
        System.out.println("Address: " + address2);
        System.out.println("Address: " + address3);
        System.out.println("Address: " + address4);
        System.out.println("Address: " + address5);
        System.out.println("Address: " + address6);
        System.out.println("Address: " + address7);
        System.out.println("Cop Status: " + cop_status);
        System.out.println("Year: " + year);
        System.out.println("Fiscal Year: " + F_year);
        System.out.println("Region : " + region);

		JSONObject memberJson = new JSONObject();
		memberJson.put("name", name);
		memberJson.put("gender", gender);
		memberJson.put("qualification", qualification);
		memberJson.put("address", address);
		memberJson.put("address", address1);
		memberJson.put("address", address2);
		memberJson.put("address", address3);
		memberJson.put("address", address4);
		memberJson.put("address", address5);
		memberJson.put("address", address6);
		memberJson.put("address", address7);
		memberJson.put("cop_status", cop_status);
		memberJson.put("year", year);
		memberJson.put("F_year", F_year);
		memberJson.put("Region", region);
		
		// Convert JSON object to JSON string
		String jsonString = memberJson.toString();

		// Print the JSON string
		System.out.println(jsonString);
		}catch (Exception e) {
	    System.out.println("Member not found for ID:"+ memberId);
	    //driver.findElement(By.xpath("//input[@name=\"t1\"]")).clear();//added code to clear previous membership no
		}
		}
	}
	