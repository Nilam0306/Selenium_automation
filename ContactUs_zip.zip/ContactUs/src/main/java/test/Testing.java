package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testing {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://192.168.29.71:3000");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@class='cta-btn-flex']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//input[@name='inputField1'])[1]")).sendKeys("Nehu");
		driver.findElement(By.xpath("//input[@id='lastNameId']")).sendKeys("N");
		driver.findElement(By.xpath("//input[@name='inputField2']")).sendKeys("9999999999");
		Thread.sleep(1000);
		driver.findElement(By.id("emailId")).sendKeys("n@n.com");
		driver.findElement(By.xpath("//textarea[@name='inputField4']")).sendKeys("Hi there!!");
		//Thread.sleep(1000);
		//driver.findElement(By.xpath("//button[@class='contact-submit-btn cta-btn-flex']")).click();
		

	} 

}
