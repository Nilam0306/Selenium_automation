package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

import org.openqa.selenium.WebElement;

public class MembershipNo {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\chrome1\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://112.133.194.254/lom.asp");
		driver.manage().window().maximize();
		//driver.manage().timeouts().getImplicitWaitTimeout();
		//String memberId = "010001";
		//Thread.sleep(5000);
		//getMemberIdInfo(driver, memberId);
		//String memberId1 = "903837";
		//Thread.sleep(5000);
		//getMemberIdInfo(driver, memberId1);
		// Close the WebDriver
		
		 int startMemberId = 100000;  // Start membership number
	     int endMemberId = 100020;    // End membership number
	     
	     
	        Workbook workbook = new XSSFWorkbook();
	        Sheet sheet = workbook.createSheet("MemberDetails");

	        // Create the header row
	        Row headerRow = sheet.createRow(0);
	        String[] headers = {"Name", "Gender", "Qualification", "Address", "Address1", "Address2", "Address3",
	                "Address4", "Address5", "Address6", "Address7", "Cop Status", "Year", "Fiscal Year", "Region"};
	        for (int i = 0; i < headers.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers[i]);
	        }



	        for (int memberId = startMemberId; memberId <= endMemberId; memberId++) {
	            String memberIdStr = String.format("%06d", memberId); // Format as 6-digit string
	            Thread.sleep(2000);
	            try {
	            getMemberIdInfo(driver, memberIdStr,sheet);
	            driver.findElement(By.xpath("//input[@name=\"t1\"]")).clear();
	            Thread.sleep(2000);
	            }catch (Exception e) {
	                System.out.println("Member not found for ID:" + memberId);
	            }
	        }// Save the workbook to a file
	        try (FileOutputStream fileOut = new FileOutputStream("MemberDetails.xlsx")) {
	            workbook.write(fileOut);
	}catch(Exception e) {
		System.out.println(e);
	}
		driver.quit();
		workbook.close();
	}

	private static void getMemberIdInfo(WebDriver driver, String memberId,Sheet sheet) throws InterruptedException {
		driver.findElement(By.xpath("//input[@name=\"t1\"]")).sendKeys(memberId);
		driver.findElement(By.xpath("//input[@value=\"Submit\"]")).click();
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10000));
		
		try {
			
		WebElement memberDetails=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='t1']")));
		Thread.sleep(1000);
		
	    //String name = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[2]")).getText();
		String name = memberDetails.findElement(By.xpath("(((//form[@name='frm']//table)[2]/tbody/tr)[2]/td)[2]/b")).getText();
		//(((//form[@name='frm']//table)[2]/tbody/tr)[2]/td)[2]/b		
		//String gender = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[3]")).getText();
		String gender = memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[3]//td/b")).getText();
		
		//String qualification = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[4]")).getText();
		String qualification = memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[4]/td/b")).getText();		
		String address =memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[5]/td/b")).getText();
		String address1=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[6]/td/b")).getText();
		String address2=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[9]/td/b")).getText();
		String address3=memberDetails.findElement(By.xpath("((//table)[4]//tbody/tr)[10]/td/b")).getText();
		String address4=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[5]/td)[4]/b")).getText();
		String address5=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[9]/td)[4]/b")).getText();
		String address6=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[10]/td)[4]/b")).getText();
		String address7=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[11]/td)[4]/b")).getText();
		
		//String address = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[5]")).getText();
		
		//String cop_status = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[12]")).getText();
		String cop_status = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[12]/td)/b")).getText();
		
		//String year = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[13]")).getText();
		String year = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[13]/td)/b")).getText();
		
		//String F_year = memberDetails.findElement(By.xpath("(//table[@border=\"0\"])[4]/tbody/tr[14]")).getText();
		String F_year = memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[14]/td)/b")).getText();
		
		String region=memberDetails.findElement(By.xpath("(((//table)[4]//tbody/tr)[14]/td)[4]/b")).getText();	
		
		
		// Create a new row for each member
        int rowNum = sheet.getLastRowNum() + 1;
        Row row = sheet.createRow(rowNum);

        // Add data to the row
        row.createCell(0).setCellValue(name);
        row.createCell(1).setCellValue(gender);
        row.createCell(2).setCellValue(qualification);
        row.createCell(3).setCellValue(address);
        row.createCell(4).setCellValue(address1);
        row.createCell(5).setCellValue(address2);
        row.createCell(6).setCellValue(address3);
        row.createCell(7).setCellValue(address4);
        row.createCell(8).setCellValue(address5);
        row.createCell(9).setCellValue(address6);
        row.createCell(10).setCellValue(address7);
        row.createCell(11).setCellValue(cop_status);
        row.createCell(12).setCellValue(year);
        row.createCell(13).setCellValue(F_year);
        row.createCell(14).setCellValue(region);
    
		
		/*System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Qualification: " + qualification);
        System.out.println("Address: " + address);
        System.out.println("Address: " + address1);
        System.out.println("Address: " + address2);
        System.out.println("Address: " + address3);
        System.out.println("Address: " + address4);
        System.out.println("Address: " + address5);
        System.out.println("Address: " + address6);
        System.out.println("Address: " + address7);
        System.out.println("Cop Status: " + cop_status);
        System.out.println("Year: " + year);
        System.out.println("Fiscal Year: " + F_year);
        System.out.println("Region : " + region);

		JSONObject memberJson = new JSONObject();
		memberJson.put("name", name);
		memberJson.put("gender", gender);
		memberJson.put("qualification", qualification);
		memberJson.put("address", address);
		memberJson.put("address", address1);
		memberJson.put("address", address2);
		memberJson.put("address", address3);
		memberJson.put("address", address4);
		memberJson.put("address", address5);
		memberJson.put("address", address6);
		memberJson.put("address", address7);
		memberJson.put("cop_status", cop_status);
		memberJson.put("year", year);
		memberJson.put("F_year", F_year);
		memberJson.put("Region", region);
		
		// Convert JSON object to JSON string
		String jsonString = memberJson.toString();

		// Print the JSON string
		System.out.println(jsonString);*/
		}catch (Exception e) {
	    System.out.println("Member not found for ID:"+ memberId);
		}
		
		}
	}
	

